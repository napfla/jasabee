<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\WorkerModel;
use App\Models\CategoryModel;

class ProfileController extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $userModel = new UserModel();
        $data['user'] = $userModel->find(session()->get('user_id'));
        $data['role'] = session()->get('user_role');

        if ($data['role'] === 'worker') {
            $workerModel = new WorkerModel();
            $categoryModel = new CategoryModel();
            $data['worker'] = $workerModel->getWorkerByUserId(session()->get('user_id'));
            $data['categories'] = $categoryModel->findAll();
        }

        return view('profile/index', $data);
    }

    public function update()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $userModel = new UserModel();
        $id = session()->get('user_id');

        $userModel->update($id, [
            'name'    => $this->request->getPost('name'),
            'phone'   => $this->request->getPost('phone'),
            'address' => $this->request->getPost('address'),
        ]);

        // Update session name
        session()->set('user_name', $this->request->getPost('name'));

        // Update worker profile juga kalau role worker
        if (session()->get('user_role') === 'worker') {
            $workerModel = new WorkerModel();
            $worker = $workerModel->getWorkerByUserId($id);
            if ($worker) {
                $workerModel->update($worker['id'], [
                    'category_id' => $this->request->getPost('category_id'),
                    'bio'         => $this->request->getPost('bio'),
                    'experience'  => $this->request->getPost('experience'),
                    'price'       => $this->request->getPost('price'),
                    'status'      => $this->request->getPost('status'),
                ]);
            }
        }

        return redirect()->to('/profile')->with('success', 'Profil berhasil diupdate!');
    }

    public function updatePassword()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $userModel = new UserModel();
        $user = $userModel->find(session()->get('user_id'));

        $oldPassword = $this->request->getPost('old_password');
        $newPassword = $this->request->getPost('new_password');
        $confirmPassword = $this->request->getPost('confirm_password');

        if (!password_verify($oldPassword, $user['password'])) {
            return redirect()->to('/profile')->with('error_password', 'Password lama salah!');
        }

        if ($newPassword !== $confirmPassword) {
            return redirect()->to('/profile')->with('error_password', 'Konfirmasi password tidak cocok!');
        }

        if (strlen($newPassword) < 6) {
            return redirect()->to('/profile')->with('error_password', 'Password minimal 6 karakter!');
        }

        $userModel->update($user['id'], [
            'password' => password_hash($newPassword, PASSWORD_DEFAULT)
        ]);

        return redirect()->to('/profile')->with('success_password', 'Password berhasil diubah!');
    }
}