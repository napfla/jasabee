<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\WorkerModel;
use App\Models\CategoryModel;

class HomeController extends BaseController
{
    public function index()
    {
        // Cek apakah sudah login
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $categoryModel = new CategoryModel();
        $workerModel   = new WorkerModel();

        $data = [
            'user'       => session()->get(),
            'categories' => $categoryModel->findAll(),
            'workers'    => $workerModel->getWorkersWithDetails(),
        ];

        return view('customer/home', $data);
    }
}