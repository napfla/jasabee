<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\WorkerModel;
use App\Models\CategoryModel;
use App\Models\OrderModel;
use App\Models\ReviewModel;

class CustomerController extends BaseController
{
    protected function isCustomer()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }
        if (session()->get('user_role') !== 'customer') {
            // Redirect sesuai role
            if (session()->get('user_role') === 'admin') {
                return redirect()->to('/admin/dashboard');
            } elseif (session()->get('user_role') === 'worker') {
                return redirect()->to('/worker/dashboard');
            }
        }
    }

    public function home()
    {
    $this->isCustomer();
    $categoryModel = new CategoryModel();
    $workerModel   = new WorkerModel();

    $data = [
        'user'       => session()->get(),
        'categories' => $categoryModel->findAll(),
        'workers'    => $workerModel->getWorkersWithDetails(),
    ];

    return view('customer/home', $data);
    }

    public function workersByCategory($category_id)
    {
        $this->isCustomer();
        $categoryModel = new CategoryModel();
        $workerModel   = new WorkerModel();

        $data = [
            'category' => $categoryModel->find($category_id),
            'workers'  => $workerModel->getWorkersWithDetails($category_id),
        ];

        return view('customer/workers_by_category', $data);
    }

    public function createOrder($worker_id)
    {
        $this->isCustomer();
        $workerModel = new WorkerModel();
        $worker      = $workerModel->getWorkerByUserId(null);

        // ambil worker by id
        $worker = $workerModel
            ->select('workers.*, users.name, users.phone, categories.name as category_name, categories.id as category_id')
            ->join('users', 'users.id = workers.user_id')
            ->join('categories', 'categories.id = workers.category_id')
            ->where('workers.id', $worker_id)
            ->first();

        $data = ['worker' => $worker];
        return view('customer/create_order', $data);
    }

    public function storeOrder()
    {
        $this->isCustomer();
        $orderModel = new OrderModel();

        $orderModel->save([
            'customer_id' => session()->get('user_id'),
            'worker_id'   => $this->request->getPost('worker_id'),
            'category_id' => $this->request->getPost('category_id'),
            'description' => $this->request->getPost('description'),
            'address'     => $this->request->getPost('address'),
            'date'        => $this->request->getPost('date'),
            'status'      => 'pending',
        ]);

        return redirect()->to('/customer/orders')->with('success', 'Pesanan berhasil dibuat!');
    }

    public function myOrders()
    {
        $this->isCustomer();
        $orderModel = new OrderModel();
        $data['orders'] = $orderModel->getOrdersByCustomer(session()->get('user_id'));
        return view('customer/my_orders', $data);
    }

    public function storeReview()
    {
        $this->isCustomer();
        $reviewModel = new ReviewModel();

        $reviewModel->save([
            'order_id'    => $this->request->getPost('order_id'),
            'customer_id' => session()->get('user_id'),
            'rating'      => $this->request->getPost('rating'),
            'comment'     => $this->request->getPost('comment'),
        ]);

        return redirect()->to('/customer/orders')->with('success', 'Ulasan berhasil dikirim!');
    }
}