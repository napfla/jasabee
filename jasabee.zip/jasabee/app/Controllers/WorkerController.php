<?php

namespace App\Controllers;

use App\Models\WorkerModel;
use App\Models\OrderModel;
use App\Models\CategoryModel;

class WorkerController extends BaseController
{
    protected function isWorker()
    {
        if (!session()->get('logged_in') || session()->get('user_role') !== 'worker') {
            return redirect()->to('/login');
        }
    }

    public function dashboard()
    {
    $this->isWorker();
    $workerModel = new WorkerModel();
    $orderModel  = new OrderModel();

    $worker = $workerModel->getWorkerByUserId(session()->get('user_id'));

    // Cek apakah worker sudah lengkapi profil
    if (!$worker) {
        return redirect()->to('/worker/complete-profile');
    }

    $data = [
        'worker'         => $worker,
        'orders'         => $orderModel->getOrdersByWorker($worker['id']),
        'total_orders'   => $orderModel->where('worker_id', $worker['id'])->countAllResults(),
        'pending_orders' => $orderModel->where('worker_id', $worker['id'])->where('status', 'pending')->countAllResults(),
        'done_orders'    => $orderModel->where('worker_id', $worker['id'])->where('status', 'done')->countAllResults(),
    ];

    return view('worker/dashboard', $data);
    }

    public function completeProfile()
    {
        $this->isWorker();
        $workerModel = new WorkerModel();

        // Kalau sudah punya profil redirect ke dashboard
        $worker = $workerModel->getWorkerByUserId(session()->get('user_id'));
        if ($worker) {
            return redirect()->to('/worker/dashboard');
        }

        $categoryModel = new CategoryModel();
        $data['categories'] = $categoryModel->findAll();

        return view('worker/complete_profile', $data);
    }

    public function saveProfile()
    {
        $this->isWorker();
        $workerModel = new WorkerModel();

        $workerModel->save([
            'user_id'     => session()->get('user_id'),
            'category_id' => $this->request->getPost('category_id'),
            'bio'         => $this->request->getPost('bio'),
            'experience'  => $this->request->getPost('experience'),
            'price'       => $this->request->getPost('price'),
            'status'      => 'available',
            'is_verified' => 0, // belum diverifikasi admin
        ]);

        return redirect()->to('/worker/dashboard')->with('success', 'Profil berhasil disimpan! Tunggu verifikasi admin.');
    }

    public function updateStatus($order_id)
    {
        $this->isWorker();
        $orderModel = new OrderModel();

        $orderModel->update($order_id, [
            'status' => $this->request->getPost('status')
        ]);

        return redirect()->to('/worker/dashboard')->with('success', 'Status pesanan berhasil diupdate!');
    }

    public function editProfile()
    {
        $this->isWorker();
        $workerModel   = new WorkerModel();
        $categoryModel = new CategoryModel();

        $data = [
            'worker'     => $workerModel->getWorkerByUserId(session()->get('user_id')),
            'categories' => $categoryModel->findAll(),
        ];

        return view('worker/edit_profile', $data);
    }

    public function updateProfile()
    {
        $this->isWorker();
        $workerModel = new WorkerModel();
        $worker      = $workerModel->getWorkerByUserId(session()->get('user_id'));

        $workerModel->update($worker['id'], [
            'category_id' => $this->request->getPost('category_id'),
            'bio'         => $this->request->getPost('bio'),
            'experience'  => $this->request->getPost('experience'),
            'price'       => $this->request->getPost('price'),
            'status'      => $this->request->getPost('status'),
        ]);

        return redirect()->to('/worker/dashboard')->with('success', 'Profil berhasil diupdate!');
    }
}