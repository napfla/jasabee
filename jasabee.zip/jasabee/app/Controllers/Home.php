<?php

namespace App\Controllers;

use App\Models\CategoryModel;
use App\Models\WorkerModel;
use App\Models\OrderModel;
use App\Models\ReviewModel;

class Home extends BaseController
{
    public function index()
    {
        $categoryModel = new CategoryModel();
        $workerModel   = new WorkerModel();
        $orderModel    = new OrderModel();
        $reviewModel   = new ReviewModel();

        $avg = $reviewModel->selectAvg('rating', 'avg_rating')->first();

        $data = [
            'categories'   => $categoryModel->findAll(),
            'workers'      => $workerModel->getWorkersWithDetails(),
            'testimonials' => $reviewModel->getLatestReviews(6),
            'stats' => [
                'workers'    => $workerModel->where('status', 'available')->countAllResults(),
                'orders'     => $orderModel->where('status', 'done')->countAllResults(),
                'categories' => $categoryModel->countAllResults(),
                'avg_rating' => $avg['avg_rating'] ?? 0,
            ],
        ];

        return view('home', $data);
    }
}