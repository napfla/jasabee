<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\WorkerModel;
use App\Models\CategoryModel;
use App\Models\OrderModel;
use App\Models\ReviewModel;

class AdminController extends BaseController
{
    protected function isAdmin()
    {
        if (!session()->get('logged_in') || session()->get('user_role') !== 'admin') {
            return redirect()->to('/login');
        }
        return true;
    }

    public function dashboard()
    {
        $this->isAdmin();

        $userModel     = new UserModel();
        $workerModel   = new WorkerModel();
        $categoryModel = new CategoryModel();
        $orderModel    = new OrderModel();

        $data = [
            'total_users'      => $userModel->countAll(),
            'total_workers'    => $workerModel->countAll(),
            'total_categories' => $categoryModel->countAll(),
            'total_orders'     => $orderModel->countAll(),
            'recent_orders'    => $orderModel->getOrdersWithDetails(5),
            'recent_users'     => $userModel->orderBy('created_at', 'DESC')->limit(5)->findAll(),
        ];

        return view('admin/dashboard', $data);
    }

    // ===== CRUD USERS =====
    public function users()
    {
        $this->isAdmin();
        $userModel = new UserModel();
        $data['users'] = $userModel->orderBy('created_at', 'DESC')->findAll();
        return view('admin/users/index', $data);
    }

    public function createUser()
    {
        $this->isAdmin();
        return view('admin/users/create');
    }

    public function storeUser()
    {
        $this->isAdmin();
        $userModel = new UserModel();

        $rules = [
            'name'     => 'required|min_length[3]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'role'     => 'required|in_list[admin,customer,worker]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $userModel->save([
            'name'     => $this->request->getPost('name'),
            'email'    => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'phone'    => $this->request->getPost('phone'),
            'address'  => $this->request->getPost('address'),
            'role'     => $this->request->getPost('role'),
        ]);

        return redirect()->to('/admin/users')->with('success', 'User berhasil ditambahkan!');
    }

    public function editUser($id)
    {
        $this->isAdmin();
        $userModel = new UserModel();
        $data['user'] = $userModel->find($id);
        return view('admin/users/edit', $data);
    }

    public function updateUser($id)
    {
        $this->isAdmin();
        $userModel = new UserModel();

        $userModel->update($id, [
            'name'    => $this->request->getPost('name'),
            'email'   => $this->request->getPost('email'),
            'phone'   => $this->request->getPost('phone'),
            'address' => $this->request->getPost('address'),
            'role'    => $this->request->getPost('role'),
        ]);

        return redirect()->to('/admin/users')->with('success', 'User berhasil diupdate!');
    }

    public function deleteUser($id)
    {
        $this->isAdmin();
        $userModel = new UserModel();
        $userModel->delete($id);
        return redirect()->to('/admin/users')->with('success', 'User berhasil dihapus!');
    }

    public function categories()
    {
    $this->isAdmin();
    $categoryModel = new CategoryModel();
    $data['categories'] = $categoryModel->orderBy('created_at', 'DESC')->findAll();
    return view('admin/categories/index', $data);
    }

    public function createCategory()
    {
    $this->isAdmin();
    return view('admin/categories/create');
    }

    public function storeCategory()
    {
    $categoryModel = new CategoryModel();

    $rules = ['name' => 'required|min_length[3]'];

    if (!$this->validate($rules)) {
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    $categoryModel->save([
        'name'        => $this->request->getPost('name'),
        'icon'        => $this->request->getPost('icon'),
        'description' => $this->request->getPost('description'),
    ]);

    return redirect()->to('/admin/categories')->with('success', 'Kategori berhasil ditambahkan!');
    }

    public function editCategory($id)
    {
    $categoryModel = new CategoryModel();
    $data['category'] = $categoryModel->find($id);
    return view('admin/categories/edit', $data);
    }

    public function updateCategory($id)
    {
    $categoryModel = new CategoryModel();
    $categoryModel->update($id, [
        'name'        => $this->request->getPost('name'),
        'icon'        => $this->request->getPost('icon'),
        'description' => $this->request->getPost('description'),
    ]);
    return redirect()->to('/admin/categories')->with('success', 'Kategori berhasil diupdate!');
    }

    public function deleteCategory($id)
    {
    $categoryModel = new CategoryModel();
    $categoryModel->delete($id);
    return redirect()->to('/admin/categories')->with('success', 'Kategori berhasil dihapus!');
    }

    // ===== CRUD WORKERS =====
    public function workers()
    {
        $workerModel = new WorkerModel();
        $data['workers'] = $workerModel->getWorkersWithDetails();
        return view('admin/workers/index', $data);
    }

    public function createWorker()
    {
        $userModel     = new UserModel();
        $categoryModel = new CategoryModel();
        $data['users']      = $userModel->where('role', 'worker')->findAll();
        $data['categories'] = $categoryModel->findAll();
        return view('admin/workers/create', $data);
    }

    public function storeWorker()
    {
        $workerModel = new WorkerModel();

        $workerModel->save([
            'user_id'     => $this->request->getPost('user_id'),
            'category_id' => $this->request->getPost('category_id'),
            'bio'         => $this->request->getPost('bio'),
            'experience'  => $this->request->getPost('experience'),
            'price'       => $this->request->getPost('price'),
            'status'      => 'available',
        ]);

        return redirect()->to('/admin/workers')->with('success', 'Penyedia jasa berhasil ditambahkan!');
    }

    public function editWorker($id)
    {
        $workerModel   = new WorkerModel();
        $categoryModel = new CategoryModel();
        $data['worker']     = $workerModel->find($id);
        $data['categories'] = $categoryModel->findAll();
        return view('admin/workers/edit', $data);
    }

    public function updateWorker($id)
    {
        $workerModel = new WorkerModel();
        $workerModel->update($id, [
            'category_id' => $this->request->getPost('category_id'),
            'bio'         => $this->request->getPost('bio'),
            'experience'  => $this->request->getPost('experience'),
            'price'       => $this->request->getPost('price'),
            'status'      => $this->request->getPost('status'),
        ]);
        return redirect()->to('/admin/workers')->with('success', 'Penyedia jasa berhasil diupdate!');
    }

    public function deleteWorker($id)
    {
        $workerModel = new WorkerModel();
        $workerModel->delete($id);
        return redirect()->to('/admin/workers')->with('success', 'Penyedia jasa berhasil dihapus!');
    }

    // ===== ORDERS =====
    public function orders()
    {
        $orderModel = new OrderModel();
        $data['orders'] = $orderModel->getOrdersWithDetails();
        return view('admin/orders/index', $data);
    }

    public function orderDetail($id)
    {
        $orderModel  = new OrderModel();
        $reviewModel = new ReviewModel();
        $data['order']  = $orderModel->getOrdersWithDetails()->where('orders.id', $id)->first();
        $data['review'] = $reviewModel->where('order_id', $id)->first();
        return view('admin/orders/detail', $data);
    }

    public function updateOrderStatus($id)
    {
        $orderModel = new OrderModel();
        $orderModel->update($id, [
            'status' => $this->request->getPost('status')
        ]);
        return redirect()->to('/admin/orders')->with('success', 'Status pesanan berhasil diupdate!');
    }

    public function deleteOrder($id)
    {
        $orderModel = new OrderModel();
        $orderModel->delete($id);
        return redirect()->to('/admin/orders')->with('success', 'Pesanan berhasil dihapus!');
    }

    // ===== REVIEWS =====
    public function reviews()
    {
    $reviewModel = new ReviewModel();
    $data['reviews'] = $reviewModel
        ->select('reviews.*, users.name as customer_name')
        ->join('users', 'users.id = reviews.customer_id')
        ->orderBy('reviews.created_at', 'DESC')
        ->findAll();
    return view('admin/reviews/index', $data);
    }

    public function verifyWorker($id)
    {
        $workerModel = new WorkerModel();
        $workerModel->update($id, ['is_verified' => 1]);
        return redirect()->to('/admin/workers')->with('success', 'Penyedia jasa berhasil diverifikasi!');
    }

    public function unverifyWorker($id)
    {
        $workerModel = new WorkerModel();
        $workerModel->update($id, ['is_verified' => 0]);
        return redirect()->to('/admin/workers')->with('success', 'Verifikasi penyedia jasa dicabut!');
    }
}
