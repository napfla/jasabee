<?php

namespace App\Models;

use CodeIgniter\Model;

class ReviewModel extends Model
{
    protected $table         = 'reviews';
    protected $primaryKey    = 'id';
    protected $allowedFields = [
        'order_id', 'customer_id', 'rating', 'comment'
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getReviewsByWorker($worker_id)
    {
        return $this->select('reviews.*, users.name as customer_name, orders.id as order_id')
            ->join('users', 'users.id = reviews.customer_id')
            ->join('orders', 'orders.id = reviews.order_id')
            ->where('orders.worker_id', $worker_id)
            ->orderBy('reviews.created_at', 'DESC')
            ->findAll();
    }

    // Ulasan terbaru untuk ditampilkan di landing page
    public function getLatestReviews($limit = 6)
    {
        return $this->select('reviews.*, 
                users.name as customer_name, 
                wu.name as worker_name, 
                categories.name as category_name')
            ->join('users', 'users.id = reviews.customer_id')
            ->join('orders', 'orders.id = reviews.order_id')
            ->join('workers', 'workers.id = orders.worker_id')
            ->join('users as wu', 'wu.id = workers.user_id')
            ->join('categories', 'categories.id = orders.category_id')
            ->orderBy('reviews.created_at', 'DESC')
            ->limit($limit)
            ->findAll();
    }
}