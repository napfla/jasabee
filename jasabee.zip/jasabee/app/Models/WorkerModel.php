<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkerModel extends Model
{
    protected $table         = 'workers';
    protected $primaryKey    = 'id';
    protected $allowedFields = [
    'user_id', 'category_id', 'bio', 'experience', 'photo', 'price', 'status', 'is_verified'
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getWorkersWithDetails($category_id = null)
    {
    $builder = $this->select('workers.*, users.name, users.phone, users.address, categories.name as category_name')
                    ->join('users', 'users.id = workers.user_id')
                    ->join('categories', 'categories.id = workers.category_id')
                    ->where('workers.status', 'available');

    if ($category_id) {
        $builder->where('workers.category_id', $category_id);
    }

    return $builder->findAll();
    }

    public function getWorkerByUserId($user_id)
    {
        return $this->select('workers.*, users.name, users.phone, users.address, categories.name as category_name')
                    ->join('users', 'users.id = workers.user_id')
                    ->join('categories', 'categories.id = workers.category_id')
                    ->where('workers.user_id', $user_id)
                    ->first();
    }
}