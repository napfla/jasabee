<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table         = 'orders';
    protected $primaryKey    = 'id';
    protected $allowedFields = [
        'customer_id', 'worker_id', 'category_id', 'description', 'address', 'date', 'status'
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getOrdersWithDetails($limit = null)
    {
        $builder = $this->select('orders.*, 
                users.name as customer_name, 
                users.phone as customer_phone,
                workers.id as worker_id,
                wu.name as worker_name,
                categories.name as category_name')
            ->join('users', 'users.id = orders.customer_id')
            ->join('workers', 'workers.id = orders.worker_id')
            ->join('users as wu', 'wu.id = workers.user_id')
            ->join('categories', 'categories.id = orders.category_id')
            ->orderBy('orders.created_at', 'DESC');

        if ($limit) {
            $builder->limit($limit);
        }

        return $builder->findAll();
    }

    public function getOrdersByCustomer($customer_id)
    {
        return $this->select('orders.*, 
                wu.name as worker_name,
                categories.name as category_name')
            ->join('workers', 'workers.id = orders.worker_id')
            ->join('users as wu', 'wu.id = workers.user_id')
            ->join('categories', 'categories.id = orders.category_id')
            ->where('orders.customer_id', $customer_id)
            ->orderBy('orders.created_at', 'DESC')
            ->findAll();
    }

    public function getOrdersByWorker($worker_id)
    {
        return $this->select('orders.*, 
                users.name as customer_name,
                users.phone as customer_phone,
                categories.name as category_name')
            ->join('users', 'users.id = orders.customer_id')
            ->join('categories', 'categories.id = orders.category_id')
            ->where('orders.worker_id', $worker_id)
            ->orderBy('orders.created_at', 'DESC')
            ->findAll();
    }
}