<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JasaBee - Layanan Serba Bisa</title>
    <meta name="description" content="JasaBee - Platform jasa panggilan terpercaya untuk semua kebutuhanmu">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@600;700;800&family=Poppins:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="/bizland/assets/css/main.css">
    <style>
        :root { --accent-color: #D85A30; --heading-color: #1a1a2e; }
        body { font-family: 'Poppins', sans-serif; }
        .btn-jasabee { background: #D85A30; color: #fff; border: none; padding: 10px 28px; border-radius: 4px; font-weight: 500; }
        .btn-jasabee:hover { background: #c04828; color: #fff; }
        .btn-outline-jasabee { background: transparent; color: #D85A30; border: 2px solid #D85A30; padding: 10px 28px; border-radius: 4px; font-weight: 500; }
        .btn-outline-jasabee:hover { background: #D85A30; color: #fff; }
        .cat-card { border-radius: 12px; border: 1px solid #f0f0f0; padding: 24px 16px; text-align: center; transition: 0.2s; height: 100%; }
        .cat-card:hover { border-color: #D85A30; transform: translateY(-4px); box-shadow: 0 8px 24px rgba(216,90,48,0.1); }
        .worker-card { border-radius: 12px; border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.07); transition: 0.2s; height: 100%; }
        .worker-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(0,0,0,0.1); }
        .worker-avatar { width: 56px; height: 56px; border-radius: 50%; background: #FAECE7; display: flex; align-items: center; justify-content: center; font-weight: 800; color: #D85A30; font-size: 20px; flex-shrink: 0; }
        .step-num { width: 56px; height: 56px; border-radius: 50%; background: #D85A30; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 800; margin: 0 auto 16px; }
        footer { background: #1a1a2e; color: #fff; padding: 48px 0 24px; }
        .footer-link { color: rgba(255,255,255,0.6); text-decoration: none; font-size: 14px; }
        .footer-link:hover { color: #D85A30; }
    </style>
</head>
<body>

<!-- Topbar -->
<div style="background:#D85A30;color:#fff;padding:8px 0;font-size:13px">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex gap-4">
            <span><i class="bi bi-envelope me-1"></i>jasabee@gmail.com</span>
            <span><i class="bi bi-telephone me-1"></i>+62 812-3456-7890</span>
        </div>
        <div class="d-flex gap-3">
            <a href="#" style="color:#fff"><i class="bi bi-instagram"></i></a>
            <a href="#" style="color:#fff"><i class="bi bi-facebook"></i></a>
            <a href="#" style="color:#fff"><i class="bi bi-whatsapp"></i></a>
        </div>
    </div>
</div>

<!-- Navbar -->
<nav id="navmenu" class="navmenu" style="background:#fff;box-shadow:0 2px 20px rgba(0,0,0,0.08)">
    <div class="container d-flex align-items-center justify-content-between py-3">
        <a href="/" class="d-flex align-items-center gap-2 text-decoration-none">
            <span style="font-size:26px">🐝</span>
            <span style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:22px;color:#D85A30">JasaBee</span>
        </a>
        <div class="d-none d-lg-flex gap-4 align-items-center">
            <a href="#layanan" style="color:#444;text-decoration:none;font-weight:500;font-size:15px">Layanan</a>
            <a href="#penyedia" style="color:#444;text-decoration:none;font-weight:500;font-size:15px">Penyedia Jasa</a>
            <a href="#cara-kerja" style="color:#444;text-decoration:none;font-weight:500;font-size:15px">Cara Kerja</a>
            <a href="#kontak" style="color:#444;text-decoration:none;font-weight:500;font-size:15px">Kontak</a>
        </div>
        <div class="d-flex gap-2">
            <a href="/login" class="btn-outline-jasabee text-decoration-none">Masuk</a>
            <a href="/register" class="btn-jasabee text-decoration-none">Daftar Gratis</a>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section id="hero" class="hero section dark-background">
    <div class="container d-flex flex-column align-items-center text-center">
        <h1 data-aos="fade-up" data-aos-delay="100">Apapun Jasanya,<br><span>JasaBee</span> Solusinya!</h1>
        <p data-aos="fade-up" data-aos-delay="200">Dari bersih-bersih rumah, antar jemput, belanja, hingga apapun yang kamu butuhkan — semua tersedia di JasaBee. Mudah, cepat, terpercaya.</p>
        <div class="d-flex gap-3" data-aos="fade-up" data-aos-delay="300">
            <a href="/register" class="btn-get-started">Pesan Sekarang</a>
            <a href="#cara-kerja" class="btn-watch-video">Cara Kerjanya?</a>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section style="background:#fff;padding:50px 0;border-bottom:1px solid #f0f0f0">
    <div class="container">
        <div class="row g-4 text-center">

            <div class="col-md-3">
                    <div style="width:60px;height:60px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:26px;color:#D85A30">
                        <i class="bi bi-list-ol"></i>
                    </div>
                    <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:28px;font-weight:800;color:#1a1a2e">3</div>
                    <div style="color:#888;font-size:13px">Langkah Proses Mudah</div>
                </div>

            <div class="col-md-3">
                <div style="width:60px;height:60px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:26px;color:#D85A30">
                    <i class="bi bi-cash-coin"></i>
                </div>
                <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:28px;font-weight:800;color:#1a1a2e">0</div>
                <div style="color:#888;font-size:13px">Biaya Pendaftaran</div>
            </div>

            <div class="col-md-3">
                <div style="width:60px;height:60px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:26px;color:#D85A30">
                    <i class="bi bi-patch-check"></i>
                </div>
                <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:28px;font-weight:800;color:#1a1a2e">100%</div>
                <div style="color:#888;font-size:13px">Worker Terverifikasi</div>
            </div>

            <div class="col-md-3">
                <div style="width:60px;height:60px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:26px;color:#D85A30">
                    <i class="bi bi-headset"></i>
                </div>
                <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:28px;font-weight:800;color:#1a1a2e">24/7</div>
                <div style="color:#888;font-size:13px">Siap Membantu</div>
            </div>

        </div>
    </div>
</section>

<!-- Layanan -->
<section id="layanan" class="services section" style="padding:60px 0;background:#f8f9fa">
    <div class="container">
        <div class="section-title text-center mb-5" data-aos="fade-up">
            <h2>Kategori Layanan</h2>
            <p>Berbagai layanan tersedia untuk memenuhi kebutuhanmu sehari-hari</p>
        </div>
        <div class="row g-3">
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $cat): ?>
                <div class="col-6 col-md-3" data-aos="fade-up">
                    <div class="cat-card bg-white">
                        <div style="font-size:40px"><?= $cat['icon'] ?? '📦' ?></div>
                        <div style="font-weight:700;font-size:15px;margin-top:10px"><?= $cat['name'] ?></div>
                        <?php if (!empty($cat['description'])): ?>
                            <div style="font-size:12px;color:#888;margin-top:4px"><?= $cat['description'] ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center text-muted">Belum ada kategori</div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Penyedia Jasa -->
<section id="penyedia" class="team section" style="padding:60px 0">
    <div class="container">
        <div class="section-title text-center mb-5" data-aos="fade-up">
            <h2>Penyedia Jasa Terpercaya</h2>
            <p>Profesional & berpengalaman siap membantu kebutuhanmu</p>
        </div>
        <div class="row g-4">
            <?php if (!empty($workers)): ?>
                <?php foreach ($workers as $worker): ?>
                <div class="col-md-4" data-aos="fade-up">
                    <div class="card worker-card">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-3 mb-3">
                                <div class="worker-avatar">
                                    <?= strtoupper(substr($worker['name'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div style="font-weight:700;font-size:15px"><?= $worker['name'] ?></div>
                                    <div style="font-size:12px;color:#D85A30;font-weight:600"><?= $worker['category_name'] ?></div>
                                </div>
                            </div>
                            <p style="font-size:13px;color:#888;line-height:1.7;margin-bottom:12px"><?= substr($worker['bio'] ?? 'Penyedia jasa profesional siap membantu.', 0, 90) ?>...</p>
                            <div class="d-flex justify-content-between align-items-center pt-2" style="border-top:1px solid #f0f0f0">
                                <span style="color:#D85A30;font-weight:700;font-size:14px"><?= $worker['price'] ?? '-' ?></span>
                                <span style="background:#EDFAF4;color:#1D9E75;font-size:11px;font-weight:600;padding:4px 12px;border-radius:20px">✓ Tersedia</span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center text-muted py-4">
                    <i class="bi bi-person-x" style="font-size:48px"></i>
                    <p class="mt-2">Belum ada penyedia jasa</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="text-center mt-5">
            <a href="/register" class="btn-jasabee text-decoration-none px-4 py-2">Daftar & Pesan Sekarang</a>
        </div>
    </div>
</section>

<!-- Cara Kerja -->
<section id="cara-kerja" style="padding:60px 0;background:#f8f9fa">
    <div class="container">
        <div class="section-title text-center mb-5" data-aos="fade-up">
            <h2>Cara Kerja JasaBee</h2>
            <p>Mudah, cepat, dan terpercaya</p>
        </div>
        <div class="row g-4 text-center">
            <div class="col-md-4" data-aos="fade-up">
                <div class="step-num">1</div>
                <h5 class="fw-bold">Daftar & Login</h5>
                <p class="text-muted">Buat akun gratis dan login ke platform JasaBee</p>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                <div class="step-num">2</div>
                <h5 class="fw-bold">Pilih & Pesan</h5>
                <p class="text-muted">Pilih penyedia jasa sesuai kebutuhan dan buat pesanan</p>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="step-num">3</div>
                <h5 class="fw-bold">Selesai & Ulasan</h5>
                <p class="text-muted">Pekerjaan selesai, beri rating dan ulasan</p>
            </div>
        </div>
    </div>
</section>

<!-- Jadi Worker -->
<section style="padding:60px 0">
    <div class="container">
        <div class="row align-items-center g-5">

            <div class="col-lg-6" data-aos="fade-right">
                <div style="border-radius:20px;overflow:hidden">
                    <img src="/bizland/assets/img/worker.jpg" alt="Penyedia Jasa JasaBee" class="img-fluid w-100" style="object-fit:cover; aspect-ratio:1/1; border-radius:20px">
                </div>
            </div><!-- end col gambar -->

            <div class="col-lg-6" data-aos="fade-left">
                <h2 style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;color:#1a1a2e" class="mb-3">Jadikan Keahlianmu <span style="color:#D85A30">Penghasilan!</span></h2>
                <p class="text-muted mb-4">Daftar sebagai penyedia jasa di JasaBee dan jangkau lebih banyak pelanggan. Gratis, mudah, dan langsung bisa terima pesanan!</p>
                <div class="d-flex flex-column gap-3 mb-4">
                    <div class="d-flex align-items-center gap-3">
                        <div style="width:40px;height:40px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:18px">✅</div>
                        <div>
                            <div class="fw-bold">Daftar Gratis</div>
                            <div class="text-muted small">Tidak ada biaya pendaftaran</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <div style="width:40px;height:40px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:18px">📱</div>
                        <div>
                            <div class="fw-bold">Kelola Pesanan Online</div>
                            <div class="text-muted small">Terima & kelola pesanan lewat dashboard</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <div style="width:40px;height:40px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:18px">⭐</div>
                        <div>
                            <div class="fw-bold">Bangun Reputasi</div>
                            <div class="text-muted small">Kumpulkan ulasan positif dari pelanggan</div>
                        </div>
                    </div>
                </div>
                <a href="/register" class="btn-jasabee text-decoration-none px-4 py-2">Daftar Jadi Penyedia Jasa</a>
            </div><!-- end col teks -->

        </div>
    </div>
</section>

<!-- CTA -->
<section style="padding:60px 0;background:#f8f9fa">
    <div class="container">
        <div style="background:linear-gradient(135deg,#D85A30,#e8824f);border-radius:20px;padding:60px;text-align:center;color:#fff">
            <h2 style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:32px" class="mb-3">Siap Beresin Semua Masalahmu?</h2>
            <p class="mb-4" style="opacity:0.9">Daftar sekarang dan temukan penyedia jasa terpercaya dalam hitungan menit</p>
            <div class="d-flex gap-3 justify-content-center flex-wrap">
                <a href="/register" style="background:#fff;color:#D85A30;padding:12px 32px;border-radius:4px;font-weight:700;text-decoration:none">Daftar Gratis Sekarang</a>
                <a href="/login" style="background:transparent;color:#fff;border:2px solid #fff;padding:12px 32px;border-radius:4px;font-weight:700;text-decoration:none">Sudah Punya Akun</a>
            </div>
        </div>
    </div>
</section>

<!-- Kontak -->
<section id="kontak" class="contact section" style="padding:60px 0">
    <div class="container">
        <div class="section-title text-center mb-5" data-aos="fade-up">
            <h2>Kontak Kami</h2>
            <p>Ada pertanyaan? Kami siap membantu</p>
        </div>
        <div class="row justify-content-center g-3">
            <div class="col-md-4">
                <div style="background:#fff;border-radius:12px;border:1px solid #f0f0f0;padding:20px;display:flex;align-items:center;gap:14px">
                    <div style="width:48px;height:48px;border-radius:12px;background:#FAECE7;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">📧</div>
                    <div>
                        <div style="font-size:11px;color:#888;font-weight:600;text-transform:uppercase">EMAIL</div>
                        <div style="font-weight:700">jasabee@gmail.com</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div style="background:#fff;border-radius:12px;border:1px solid #f0f0f0;padding:20px;display:flex;align-items:center;gap:14px">
                    <div style="width:48px;height:48px;border-radius:12px;background:#FAECE7;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">📱</div>
                    <div>
                        <div style="font-size:11px;color:#888;font-weight:600;text-transform:uppercase">TELEPON</div>
                        <div style="font-weight:700">+62 812-3456-7890</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div style="background:#fff;border-radius:12px;border:1px solid #f0f0f0;padding:20px;display:flex;align-items:center;gap:14px">
                    <div style="width:48px;height:48px;border-radius:12px;background:#FAECE7;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">📍</div>
                    <div>
                        <div style="font-size:11px;color:#888;font-weight:600;text-transform:uppercase">ALAMAT</div>
                        <div style="font-weight:700">Banjarbaru, Kalimantan Selatan</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer>
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <span style="font-size:26px">🐝</span>
                    <span style="font-weight:800;font-size:20px;color:#D85A30">JasaBee</span>
                </div>
                <p style="color:rgba(255,255,255,0.6);font-size:14px">Platform jasa panggilan serba bisa terpercaya di Kalimantan Selatan.</p>
            </div>
            <div class="col-md-4">
                <div style="font-weight:700;margin-bottom:16px">Menu</div>
                <div class="d-flex flex-column gap-2">
                    <a href="#layanan" class="footer-link">Layanan</a>
                    <a href="#penyedia" class="footer-link">Penyedia Jasa</a>
                    <a href="#cara-kerja" class="footer-link">Cara Kerja</a>
                    <a href="#kontak" class="footer-link">Kontak</a>
                </div>
            </div>
            <div class="col-md-4">
                <div style="font-weight:700;margin-bottom:16px">Akun</div>
                <div class="d-flex flex-column gap-2">
                    <a href="/login" class="footer-link">Masuk</a>
                    <a href="/register" class="footer-link">Daftar Gratis</a>
                </div>
            </div>
        </div>
        <hr style="border-color:rgba(255,255,255,0.1)">
        <p class="text-center mb-0" style="color:rgba(255,255,255,0.4);font-size:13px">© 2026 JasaBee — Sistem Informasi Direktori Layanan Serba Bisa Berbasis Web</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/bizland/assets/js/main.js"></script>
</body>
</html>