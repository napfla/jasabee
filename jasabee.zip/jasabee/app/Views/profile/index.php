<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - JasaBee</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { background: #f4f6fb; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
        .profile-card { background: #fff; border-radius: 16px; border: 0.5px solid #e8e8e8; padding: 24px; }
        .avatar-big { width: 80px; height: 80px; border-radius: 50%; background: #FAECE7; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: 800; color: #D85A30; flex-shrink: 0; }
        .role-badge { padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .role-admin { background: #FAECE7; color: #993C1D; }
        .role-customer { background: #E6F1FB; color: #185FA5; }
        .role-worker { background: #E1F5EE; color: #0F6E56; }
        .tab-btn { background: transparent; border: none; padding: 10px 20px; font-size: 14px; font-weight: 500; color: #888; border-bottom: 2px solid transparent; cursor: pointer; }
        .tab-btn.active { color: #D85A30; border-bottom-color: #D85A30; }
        .section-title { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 15px; font-weight: 700; color: #1a1a2e; margin-bottom: 16px; }
    </style>
</head>
<body>

<!-- Navbar sesuai role -->
<?php if ($role === 'admin'): ?>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="/admin/dashboard">🐝 JasaBee Admin</a>
        <div class="d-flex gap-3 align-items-center">
            <a href="/admin/dashboard" class="text-white text-decoration-none small">Dashboard</a>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>
<?php elseif ($role === 'worker'): ?>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/worker/dashboard">🐝 JasaBee</a>
        <div class="d-flex gap-3 align-items-center">
            <a href="/worker/dashboard" class="text-white text-decoration-none small">Dashboard</a>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>
<?php else: ?>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/customer/home">🐝 JasaBee</a>
        <div class="d-flex gap-3 align-items-center">
            <a href="/customer/home" class="text-white text-decoration-none small">Beranda</a>
            <a href="/customer/orders" class="text-white text-decoration-none small">Pesanan Saya</a>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>
<?php endif; ?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <!-- Profile Header -->
            <div class="profile-card mb-4">
                <div class="d-flex align-items-center gap-4">
                    <div class="avatar-big">
                        <?= strtoupper(substr($user['name'], 0, 2)) ?>
                    </div>
                    <div>
                        <h4 class="fw-bold mb-1" style="font-family:'Plus Jakarta Sans',sans-serif"><?= $user['name'] ?></h4>
                        <p class="text-muted mb-2 small"><?= $user['email'] ?></p>
                        <span class="role-badge role-<?= $user['role'] ?>"><?= ucfirst($user['role']) ?></span>
                    </div>
                    <?php if ($role === 'worker' && isset($worker) && $worker): ?>
                    <div class="ms-auto text-end">
                        <div style="font-size:13px;color:#888">Status</div>
                        <span class="badge <?= $worker['is_verified'] ? 'bg-success' : 'bg-warning text-dark' ?>">
                            <?= $worker['is_verified'] ? '✓ Terverifikasi' : '⏳ Belum Verifikasi' ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tabs -->
            <div class="profile-card mb-4" style="padding:0">
                <div style="border-bottom:0.5px solid #e8e8e8;padding:0 20px">
                    <button class="tab-btn active" onclick="showTab('data-diri', this)">Data Diri</button>
                    <?php if ($role === 'worker' && isset($worker) && $worker): ?>
                    <button class="tab-btn" onclick="showTab('profil-jasa', this)">Profil Jasa</button>
                    <?php endif; ?>
                    <button class="tab-btn" onclick="showTab('keamanan', this)">Keamanan</button>
                </div>

                <!-- Tab: Data Diri -->
                <div id="tab-data-diri" style="padding:24px">
                    <div class="section-title">Edit Data Diri</div>

                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <?= session()->getFlashdata('success') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form action="/profile/update" method="POST">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Nama Lengkap</label>
                            <input type="text" name="name" class="form-control" value="<?= $user['name'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Email</label>
                            <input type="email" class="form-control" value="<?= $user['email'] ?>" disabled style="background:#f8f9fa">
                            <div class="form-text">Email tidak bisa diubah</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">No. HP</label>
                            <input type="text" name="phone" class="form-control" value="<?= $user['phone'] ?? '' ?>" placeholder="08xxxxxxxxxx">
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold" style="font-size:13px">Alamat</label>
                            <textarea name="address" class="form-control" rows="2" placeholder="Alamat lengkap..."><?= $user['address'] ?? '' ?></textarea>
                        </div>

                        <?php if ($role === 'worker' && isset($worker) && $worker): ?>
                        <!-- Hidden fields untuk worker profile agar tidak hilang saat update data diri -->
                        <input type="hidden" name="category_id" value="<?= $worker['category_id'] ?>">
                        <input type="hidden" name="bio" value="<?= $worker['bio'] ?>">
                        <input type="hidden" name="experience" value="<?= $worker['experience'] ?>">
                        <input type="hidden" name="price" value="<?= $worker['price'] ?>">
                        <input type="hidden" name="status" value="<?= $worker['status'] ?>">
                        <?php endif; ?>

                        <button type="submit" class="btn btn-orange">
                            <i class="bi bi-check-lg me-1"></i>Simpan Perubahan
                        </button>
                    </form>
                </div>

                <!-- Tab: Profil Jasa (worker only) -->
                <?php if ($role === 'worker' && isset($worker) && $worker): ?>
                <div id="tab-profil-jasa" style="padding:24px;display:none">
                    <div class="section-title">Edit Profil Jasa</div>
                    <form action="/profile/update" method="POST">
                        <?= csrf_field() ?>
                        <!-- Hidden fields data diri -->
                        <input type="hidden" name="name" value="<?= $user['name'] ?>">
                        <input type="hidden" name="phone" value="<?= $user['phone'] ?>">
                        <input type="hidden" name="address" value="<?= $user['address'] ?>">
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Kategori Jasa</label>
                            <select name="category_id" class="form-select" required>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= $worker['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                        <?= $cat['icon'] ?> <?= $cat['name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Bio / Deskripsi Diri</label>
                            <textarea name="bio" class="form-control" rows="3"><?= $worker['bio'] ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Pengalaman</label>
                            <input type="text" name="experience" class="form-control" value="<?= $worker['experience'] ?>" placeholder="cth: 3 tahun">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Harga / Tarif</label>
                            <input type="text" name="price" class="form-control" value="<?= $worker['price'] ?>" placeholder="cth: Rp 80.000/jam">
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold" style="font-size:13px">Status Ketersediaan</label>
                            <select name="status" class="form-select">
                                <option value="available" <?= $worker['status'] == 'available' ? 'selected' : '' ?>>Tersedia</option>
                                <option value="busy" <?= $worker['status'] == 'busy' ? 'selected' : '' ?>>Sibuk</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-orange">
                            <i class="bi bi-check-lg me-1"></i>Simpan Profil Jasa
                        </button>
                    </form>
                </div>
                <?php endif; ?>

                <!-- Tab: Keamanan -->
                <div id="tab-keamanan" style="padding:24px;display:none">
                    <div class="section-title">Ubah Password</div>

                    <?php if (session()->getFlashdata('success_password')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <?= session()->getFlashdata('success_password') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if (session()->getFlashdata('error_password')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <?= session()->getFlashdata('error_password') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form action="/profile/password" method="POST" style="max-width:400px">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Password Lama</label>
                            <input type="password" name="old_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold" style="font-size:13px">Password Baru</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold" style="font-size:13px">Konfirmasi Password Baru</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-orange">
                            <i class="bi bi-lock me-1"></i>Ubah Password
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function showTab(tabName, btn) {
    document.querySelectorAll('[id^="tab-"]').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + tabName).style.display = 'block';
    btn.classList.add('active');
}
</script>
</body>
</html>