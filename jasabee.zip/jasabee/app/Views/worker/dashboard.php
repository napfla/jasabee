<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Worker - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/worker/dashboard">🐝 JasaBee</a>
        <div class="d-flex align-items-center gap-3">
            <a href="/worker/profile/edit" class="text-white text-decoration-none">
                <i class="bi bi-person-gear me-1"></i>Edit Profil
            </a>
            <a href="/profile" class="text-white text-decoration-none">
                <i class="bi bi-person-circle me-1"></i>Profil
            </a>
            <span class="text-white">Hi, <?= session()->get('user_name') ?>!</span>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <h4 class="fw-bold mb-1">Dashboard Penyedia Jasa</h4>
    <p class="text-muted mb-4">Kelola pesanan yang masuk untukmu</p>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (!$worker): ?>
        <div class="alert alert-warning">
            <i class="bi bi-exclamation-triangle me-2"></i>
            Profilmu belum terdaftar sebagai penyedia jasa. Hubungi admin untuk mendaftarkan profilmu.
        </div>
    <?php else: ?>

    <!-- Stat Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3">
                <div class="d-flex align-items-center gap-3">
                    <div style="background:#FAECE7;width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center">
                        <i class="bi bi-clipboard-list" style="color:#D85A30;font-size:20px"></i>
                    </div>
                    <div>
                        <div class="fs-4 fw-bold"><?= $total_orders ?></div>
                        <div class="text-muted small">Total Pesanan</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3">
                <div class="d-flex align-items-center gap-3">
                    <div style="background:#FFF8E1;width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center">
                        <i class="bi bi-hourglass-split" style="color:#F59E0B;font-size:20px"></i>
                    </div>
                    <div>
                        <div class="fs-4 fw-bold"><?= $pending_orders ?></div>
                        <div class="text-muted small">Pesanan Pending</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3">
                <div class="d-flex align-items-center gap-3">
                    <div style="background:#E1F5EE;width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center">
                        <i class="bi bi-check-circle" style="color:#1D9E75;font-size:20px"></i>
                    </div>
                    <div>
                        <div class="fs-4 fw-bold"><?= $done_orders ?></div>
                        <div class="text-muted small">Pesanan Selesai</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Info Profil -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h6 class="fw-bold mb-0">Profil Saya</h6>
                <a href="/worker/profile/edit" class="btn btn-sm btn-orange">Edit Profil</a>
            </div>
            <div class="row g-2 text-muted small">
                <div class="col-md-3"><b>Kategori:</b> <?= $worker['category_name'] ?></div>
                <div class="col-md-3"><b>Pengalaman:</b> <?= $worker['experience'] ?? '-' ?></div>
                <div class="col-md-3"><b>Harga:</b> <?= $worker['price'] ?? '-' ?></div>
                <div class="col-md-3"><b>Status:</b>
                    <span class="badge <?= $worker['status'] == 'available' ? 'bg-success' : 'bg-secondary' ?>">
                        <?= $worker['status'] == 'available' ? 'Tersedia' : 'Sibuk' ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Pesanan -->
    <h5 class="fw-bold mb-3">Pesanan Masuk</h5>
    <?php if (!empty($orders)): ?>
        <?php foreach ($orders as $order): ?>
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <h6 class="fw-bold mb-1"><?= $order['category_name'] ?></h6>
                        <div class="text-muted small">
                            <i class="bi bi-person me-1"></i><?= $order['customer_name'] ?>
                            <i class="bi bi-telephone ms-2 me-1"></i><?= $order['customer_phone'] ?? '-' ?>
                        </div>
                    </div>
                    <span class="badge <?= 
                        $order['status'] == 'done' ? 'bg-success' : 
                        ($order['status'] == 'pending' ? 'bg-warning text-dark' : 
                        ($order['status'] == 'cancelled' ? 'bg-danger' : 'bg-info')) ?>">
                        <?= ucfirst($order['status']) ?>
                    </span>
                </div>
                <p class="text-muted small mb-2">
                    <i class="bi bi-card-text me-1"></i><?= $order['description'] ?>
                </p>
                <div class="d-flex gap-3 text-muted small mb-3">
                    <span><i class="bi bi-geo-alt me-1"></i><?= $order['address'] ?></span>
                    <span><i class="bi bi-calendar me-1"></i><?= $order['date'] ? date('d/m/Y', strtotime($order['date'])) : '-' ?></span>
                </div>
                <?php if ($order['status'] != 'done' && $order['status'] != 'cancelled'): ?>
                <form action="/worker/order/status/<?= $order['id'] ?>" method="POST" class="d-flex gap-2">
                    <?= csrf_field() ?>
                    <select name="status" class="form-select form-select-sm w-auto">
                        <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="confirmed" <?= $order['status'] == 'confirmed' ? 'selected' : '' ?>>Konfirmasi</option>
                        <option value="ongoing" <?= $order['status'] == 'ongoing' ? 'selected' : '' ?>>Sedang Dikerjakan</option>
                        <option value="done" <?= $order['status'] == 'done' ? 'selected' : '' ?>>Selesai</option>
                        <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>Batalkan</option>
                    </select>
                    <button type="submit" class="btn btn-orange btn-sm">Update Status</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="text-center text-muted py-5">
            <i class="bi bi-inbox fs-1"></i>
            <p class="mt-2">Belum ada pesanan masuk</p>
        </div>
    <?php endif; ?>

    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>