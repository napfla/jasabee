<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/worker/dashboard">🐝 JasaBee</a>
        <div class="d-flex align-items-center gap-3">
            <span class="text-white">Hi, <?= session()->get('user_name') ?>!</span>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="d-flex align-items-center gap-2 mb-4">
        <a href="/worker/dashboard" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left"></i>
        </a>
        <h4 class="mb-0">Edit Profil</h4>
    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="max-width:600px">
        <div class="card-body p-4">
            <form action="/worker/profile/update" method="POST">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">Kategori Jasa</label>
                    <select name="category_id" class="form-select" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $worker['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                <?= $cat['icon'] ?> <?= $cat['name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Bio / Deskripsi Diri</label>
                    <textarea name="bio" class="form-control" rows="3"><?= $worker['bio'] ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Pengalaman</label>
                    <input type="text" name="experience" class="form-control" value="<?= $worker['experience'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Harga / Tarif</label>
                    <input type="text" name="price" class="form-control" value="<?= $worker['price'] ?>">
                </div>
                <div class="mb-4">
                    <label class="form-label">Status Ketersediaan</label>
                    <select name="status" class="form-select">
                        <option value="available" <?= $worker['status'] == 'available' ? 'selected' : '' ?>>Tersedia</option>
                        <option value="busy" <?= $worker['status'] == 'busy' ? 'selected' : '' ?>>Sibuk</option>
                    </select>
                </div>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-orange">Simpan Perubahan</button>
                    <a href="/worker/dashboard" class="btn btn-outline-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>