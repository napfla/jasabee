<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lengkapi Profil - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
        .step-badge { background: #FAECE7; color: #D85A30; padding: 6px 16px; border-radius: 50px; font-size: 13px; font-weight: 700; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">🐝 JasaBee</a>
        <div class="d-flex align-items-center gap-3">
            <span class="text-white">Hi, <?= session()->get('user_name') ?>!</span>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="text-center mb-4">
                <div style="font-size:48px">🐝</div>
                <h4 class="fw-bold mt-2">Lengkapi Profil Penyedia Jasamu!</h4>
                <p class="text-muted">Isi data di bawah ini agar pelanggan bisa menemukan dan memesan jasamu. Profilmu akan diverifikasi admin sebelum aktif.</p>
                <span class="step-badge">⏳ Menunggu verifikasi admin setelah submit</span>
            </div>

            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach (session()->getFlashdata('errors') as $error): ?>
                            <li><?= $error ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <form action="/worker/save-profile" method="POST">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Kategori Jasa <span class="text-danger">*</span></label>
                            <select name="category_id" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= $cat['icon'] ?> <?= $cat['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Pilih kategori yang sesuai dengan keahlianmu</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Bio / Deskripsi Diri <span class="text-danger">*</span></label>
                            <textarea name="bio" class="form-control" rows="4" placeholder="Ceritakan keahlian dan pengalamanmu secara singkat..." required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Pengalaman</label>
                            <input type="text" name="experience" class="form-control" placeholder="cth: 3 tahun">
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Harga / Tarif <span class="text-danger">*</span></label>
                            <input type="text" name="price" class="form-control" placeholder="cth: Rp 80.000/jam" required>
                            <div class="form-text">Tentukan tarif yang sesuai dengan layananmu</div>
                        </div>
                        <button type="submit" class="btn btn-orange w-100 py-2">
                            <i class="bi bi-send me-2"></i>Kirim & Tunggu Verifikasi
                        </button>
                    </form>
                </div>
            </div>

            <div class="alert alert-info mt-3 d-flex gap-2 align-items-start">
                <i class="bi bi-info-circle mt-1"></i>
                <div>
                    <strong>Info:</strong> Setelah submit, admin akan memverifikasi profilmu. Kamu akan bisa menerima pesanan setelah diverifikasi.
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>