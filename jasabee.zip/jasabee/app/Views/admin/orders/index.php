<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { min-height: 100vh; background: #D85A30; }
        .sidebar a { color: rgba(255,255,255,0.85); text-decoration: none; display: block; padding: 10px 20px; border-radius: 8px; margin: 2px 0; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.2); color: #fff; }
        .sidebar .brand { color: #fff; font-size: 20px; font-weight: 700; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); margin-bottom: 10px; }
        .main-content { padding: 24px; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<div class="d-flex">
    <div class="sidebar p-3" style="width:240px;min-width:240px">
        <div class="brand">🐝 JasaBee</div>
        <a href="/admin/dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="/admin/users"><i class="bi bi-people me-2"></i>Kelola User</a>
        <a href="/admin/categories"><i class="bi bi-grid me-2"></i>Kategori</a>
        <a href="/admin/workers"><i class="bi bi-person-badge me-2"></i>Penyedia Jasa</a>
        <a href="/admin/orders" class="active"><i class="bi bi-clipboard-list me-2"></i>Pesanan</a>
        <a href="/admin/reviews"><i class="bi bi-star me-2"></i>Ulasan</a>
        <hr style="border-color:rgba(255,255,255,0.2)">
        <a href="/logout"><i class="bi bi-box-arrow-left me-2"></i>Logout</a>
    </div>

    <div class="flex-grow-1 main-content">
        <div class="mb-4">
            <h4 class="mb-1">Kelola Pesanan</h4>
            <p class="text-muted mb-0">Semua pesanan yang masuk di JasaBee</p>
        </div>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Customer</th>
                            <th>Penyedia Jasa</th>
                            <th>Kategori</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $i => $order): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= $order['customer_name'] ?></td>
                                <td><?= $order['worker_name'] ?></td>
                                <td><?= $order['category_name'] ?></td>
                                <td><?= $order['date'] ? date('d/m/Y', strtotime($order['date'])) : '-' ?></td>
                                <td>
                                    <span class="badge <?= 
                                        $order['status'] == 'done' ? 'bg-success' : 
                                        ($order['status'] == 'pending' ? 'bg-warning text-dark' : 
                                        ($order['status'] == 'cancelled' ? 'bg-danger' : 'bg-info')) ?>">
                                        <?= ucfirst($order['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <form action="/admin/orders/status/<?= $order['id'] ?>" method="POST" class="d-inline">
                                        <?= csrf_field() ?>
                                        <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()">
                                            <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                            <option value="confirmed" <?= $order['status'] == 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                                            <option value="ongoing" <?= $order['status'] == 'ongoing' ? 'selected' : '' ?>>Ongoing</option>
                                            <option value="done" <?= $order['status'] == 'done' ? 'selected' : '' ?>>Done</option>
                                            <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                        </select>
                                    </form>
                                    <a href="/admin/orders/delete/<?= $order['id'] ?>" class="btn btn-sm btn-danger ms-1" onclick="return confirm('Yakin hapus pesanan ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center text-muted py-3">Belum ada pesanan</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>