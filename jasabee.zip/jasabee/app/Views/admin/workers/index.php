<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Penyedia Jasa - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { min-height: 100vh; background: #D85A30; }
        .sidebar a { color: rgba(255,255,255,0.85); text-decoration: none; display: block; padding: 10px 20px; border-radius: 8px; margin: 2px 0; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.2); color: #fff; }
        .sidebar .brand { color: #fff; font-size: 20px; font-weight: 700; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); margin-bottom: 10px; }
        .main-content { padding: 24px; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<div class="d-flex">
    <div class="sidebar p-3" style="width:240px;min-width:240px">
        <div class="brand">🐝 JasaBee</div>
        <a href="/admin/dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="/admin/users"><i class="bi bi-people me-2"></i>Kelola User</a>
        <a href="/admin/categories"><i class="bi bi-grid me-2"></i>Kategori</a>
        <a href="/admin/workers" class="active"><i class="bi bi-person-badge me-2"></i>Penyedia Jasa</a>
        <a href="/admin/orders"><i class="bi bi-clipboard-list me-2"></i>Pesanan</a>
        <a href="/admin/reviews"><i class="bi bi-star me-2"></i>Ulasan</a>
        <hr style="border-color:rgba(255,255,255,0.2)">
        <a href="/logout"><i class="bi bi-box-arrow-left me-2"></i>Logout</a>
    </div>

    <div class="flex-grow-1 main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Kelola Penyedia Jasa</h4>
                <p class="text-muted mb-0">Daftar semua penyedia jasa JasaBee</p>
            </div>
            <a href="/admin/workers/create" class="btn btn-orange">
                <i class="bi bi-plus-lg me-1"></i> Tambah Penyedia Jasa
            </a>
        </div>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Kategori</th>
                            <th>Pengalaman</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th>Verifikasi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($workers)): ?>
                            <?php foreach ($workers as $i => $worker): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= $worker['name'] ?></td>
                                <td><?= $worker['category_name'] ?></td>
                                <td><?= $worker['experience'] ?? '-' ?></td>
                                <td><?= $worker['price'] ?? '-' ?></td>
                                <td>
                                    <span class="badge <?= $worker['status'] == 'available' ? 'bg-success' : 'bg-secondary' ?>">
                                        <?= $worker['status'] == 'available' ? 'Tersedia' : 'Sibuk' ?>
                                    </span>
                                </td>
                                <td>
                                <?php if ($worker['is_verified']): ?>
                                    <span class="badge bg-success d-block mb-1">✓ Terverifikasi</span>
                                    <a href="/admin/workers/unverify/<?= $worker['id'] ?>" class="btn btn-sm btn-warning d-block mb-1" onclick="return confirm('Cabut verifikasi?')">
                                        <i class="bi bi-x-circle"></i> Cabut
                                    </a>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark d-block mb-1">⏳ Belum Verifikasi</span>
                                    <a href="/admin/workers/verify/<?= $worker['id'] ?>" class="btn btn-sm btn-success d-block mb-1">
                                        <i class="bi bi-check-circle"></i> Verifikasi
                                    </a>
                                <?php endif; ?>
                                <a href="/admin/workers/edit/<?= $worker['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="/admin/workers/delete/<?= $worker['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus penyedia jasa ini?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center text-muted py-3">Belum ada penyedia jasa</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>