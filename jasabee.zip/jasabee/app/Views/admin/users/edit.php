<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { min-height: 100vh; background: #D85A30; }
        .sidebar a { color: rgba(255,255,255,0.85); text-decoration: none; display: block; padding: 10px 20px; border-radius: 8px; margin: 2px 0; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.2); color: #fff; }
        .sidebar .brand { color: #fff; font-size: 20px; font-weight: 700; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); margin-bottom: 10px; }
        .main-content { padding: 24px; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar p-3" style="width:240px;min-width:240px">
        <div class="brand">🐝 JasaBee</div>
        <a href="/admin/dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="/admin/users" class="active"><i class="bi bi-people me-2"></i>Kelola User</a>
        <a href="/admin/categories"><i class="bi bi-grid me-2"></i>Kategori</a>
        <a href="/admin/workers"><i class="bi bi-person-badge me-2"></i>Penyedia Jasa</a>
        <a href="/admin/orders"><i class="bi bi-clipboard-list me-2"></i>Pesanan</a>
        <a href="/admin/reviews"><i class="bi bi-star me-2"></i>Ulasan</a>
        <hr style="border-color:rgba(255,255,255,0.2)">
        <a href="/logout"><i class="bi bi-box-arrow-left me-2"></i>Logout</a>
    </div>

    <!-- Main Content -->
    <div class="flex-grow-1 main-content">
        <div class="d-flex align-items-center gap-2 mb-4">
            <a href="/admin/users" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h4 class="mb-0">Edit User</h4>
            </div>
        </div>

        <div class="card border-0 shadow-sm" style="max-width:600px">
            <div class="card-body p-4">
                <form action="/admin/users/update/<?= $user['id'] ?>" method="POST">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" value="<?= $user['name'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= $user['email'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">No. HP</label>
                        <input type="text" name="phone" class="form-control" value="<?= $user['phone'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <textarea name="address" class="form-control" rows="2"><?= $user['address'] ?></textarea>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-select" required>
                            <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                            <option value="customer" <?= $user['role'] == 'customer' ? 'selected' : '' ?>>Customer</option>
                            <option value="worker" <?= $user['role'] == 'worker' ? 'selected' : '' ?>>Penyedia Jasa</option>
                        </select>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-orange">Update User</button>
                        <a href="/admin/users" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>