<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kategori - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { min-height: 100vh; background: #D85A30; }
        .sidebar a { color: rgba(255,255,255,0.85); text-decoration: none; display: block; padding: 10px 20px; border-radius: 8px; margin: 2px 0; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.2); color: #fff; }
        .sidebar .brand { color: #fff; font-size: 20px; font-weight: 700; padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); margin-bottom: 10px; }
        .main-content { padding: 24px; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<div class="d-flex">
    <div class="sidebar p-3" style="width:240px;min-width:240px">
        <div class="brand">🐝 JasaBee</div>
        <a href="/admin/dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="/admin/users"><i class="bi bi-people me-2"></i>Kelola User</a>
        <a href="/admin/categories" class="active"><i class="bi bi-grid me-2"></i>Kategori</a>
        <a href="/admin/workers"><i class="bi bi-person-badge me-2"></i>Penyedia Jasa</a>
        <a href="/admin/orders"><i class="bi bi-clipboard-list me-2"></i>Pesanan</a>
        <a href="/admin/reviews"><i class="bi bi-star me-2"></i>Ulasan</a>
        <hr style="border-color:rgba(255,255,255,0.2)">
        <a href="/logout"><i class="bi bi-box-arrow-left me-2"></i>Logout</a>
    </div>

    <div class="flex-grow-1 main-content">
        <div class="d-flex align-items-center gap-2 mb-4">
            <a href="/admin/categories" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-arrow-left"></i>
            </a>
            <h4 class="mb-0">Tambah Kategori Baru</h4>
        </div>

        <?php if (session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm" style="max-width:600px">
            <div class="card-body p-4">
                <form action="/admin/categories/store" method="POST">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Nama Kategori</label>
                        <input type="text" name="name" class="form-control" value="<?= old('name') ?>" placeholder="cth: Kebersihan Rumah" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Icon (emoji)</label>
                        <input type="text" name="icon" class="form-control" value="<?= old('icon') ?>" placeholder="cth: 🧹">
                        <div class="form-text">Gunakan emoji sebagai icon kategori</div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Deskripsi singkat kategori ini..."><?= old('description') ?></textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-orange">Simpan Kategori</button>
                        <a href="/admin/categories" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>