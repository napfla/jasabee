<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - JasaBee</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { font-family: 'Poppins', sans-serif; box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #f4f6fb; }
        .sidebar { width: 220px; min-width: 220px; background: #D85A30; display: flex; flex-direction: column; position: fixed; top: 0; left: 0; height: 100vh; z-index: 100; overflow-y: auto; }
        .sidebar-brand { padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.15); }
        .sidebar-brand-name { font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; font-size: 20px; color: #fff; display: flex; align-items: center; gap: 8px; text-decoration: none; }
        .sidebar-section { padding: 12px; flex: 1; }
        .sidebar-label { font-size: 10px; font-weight: 600; color: rgba(255,255,255,0.5); letter-spacing: 1px; text-transform: uppercase; padding: 0 8px; margin-bottom: 6px; margin-top: 8px; }
        .nav-item { display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-radius: 10px; color: rgba(255,255,255,0.8); font-size: 13px; font-weight: 500; margin-bottom: 2px; cursor: pointer; text-decoration: none; }
        .nav-item.active, .nav-item:hover { background: rgba(255,255,255,0.2); color: #fff; }
        .sidebar-footer { padding: 12px; border-top: 1px solid rgba(255,255,255,0.15); }
        .main { margin-left: 220px; padding: 24px; min-height: 100vh; width: calc(100vw - 220px); }
        .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 12px; }
        .topbar h2 { font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; font-size: 22px; color: #1a1a2e; margin: 0 0 2px; }
        .topbar p { font-size: 13px; color: #888; margin: 0; }
        .avatar { width: 36px; height: 36px; border-radius: 50%; background: #FAECE7; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #D85A30; text-decoration: none; }
        .stat { background: #fff; border: 0.5px solid #e8e8e8; border-radius: 14px; padding: 16px; display: flex; align-items: center; gap: 14px; }
        .stat-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 20px; }
        .stat-num { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 26px; font-weight: 800; color: #1a1a2e; line-height: 1; }
        .stat-label { font-size: 11px; color: #888; margin-top: 3px; }
        .card-custom { background: #fff; border: 0.5px solid #e8e8e8; border-radius: 14px; padding: 18px; }
        .card-title-custom { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 14px; font-weight: 700; color: #1a1a2e; margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }
        .table-row { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 0.5px solid #f0f0f0; }
        .table-row:last-child { border-bottom: none; }
        .mini-avatar { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; flex-shrink: 0; }
        .quick-btn { background: #fff; border: 0.5px solid #e8e8e8; border-radius: 14px; padding: 14px 10px; text-align: center; cursor: pointer; text-decoration: none; display: block; transition: 0.2s; }
        .quick-btn:hover { border-color: #D85A30; transform: translateY(-2px); }
        .quick-btn-icon { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; margin: 0 auto 8px; font-size: 18px; }
        .quick-btn-label { font-size: 11px; font-weight: 600; color: #888; }
        .badge-customer { background: #E6F1FB; color: #185FA5; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-worker { background: #E1F5EE; color: #0F6E56; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-admin { background: #FAECE7; color: #993C1D; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-pending { background: #FAEEDA; color: #854F0B; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-done { background: #EAF3DE; color: #3B6D11; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-confirmed { background: #E6F1FB; color: #185FA5; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-ongoing { background: #EEEDFE; color: #534AB7; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
        .badge-cancelled { background: #FCEBEB; color: #A32D2D; font-size: 10px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
    </style>
</head>
<body>
<div style="display:flex;min-height:100vh">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <a href="/admin/dashboard" class="sidebar-brand-name">
                🐝 JasaBee
            </a>
        </div>
        <div class="sidebar-section">
            <div class="sidebar-label">Menu Utama</div>
            <a href="/admin/dashboard" class="nav-item active">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a href="/admin/users" class="nav-item">
                <i class="bi bi-people"></i> Kelola User
            </a>
            <a href="/admin/categories" class="nav-item">
                <i class="bi bi-grid"></i> Kategori
            </a>
            <a href="/admin/workers" class="nav-item">
                <i class="bi bi-person-badge"></i> Penyedia Jasa
            </a>
            <a href="/admin/orders" class="nav-item">
                <i class="bi bi-clipboard-list"></i> Pesanan
            </a>
            <a href="/admin/reviews" class="nav-item">
                <i class="bi bi-star"></i> Ulasan
            </a>
        </div>
        <div class="sidebar-footer">
            <a href="/profile" class="nav-item">
                <i class="bi bi-person-circle"></i> Profil Saya
            </a>
            <a href="/logout" class="nav-item">
                <i class="bi bi-box-arrow-left"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main">
        <!-- Topbar -->
        <div class="topbar">
            <div>
                <h2>Dashboard Admin</h2>
                <p>Selamat datang, <?= session()->get('user_name') ?>!</p>
            </div>
            <div class="d-flex align-items-center gap-2">
                <div style="background:#fff;border:0.5px solid #e8e8e8;border-radius:10px;padding:7px 14px;font-size:12px;color:#888;display:flex;align-items:center;gap:6px">
                    <i class="bi bi-calendar3"></i>
                    <?= date('l, d M Y') ?>
                </div>
                <a href="/profile" class="avatar" title="Lihat Profil">
                    <?= strtoupper(substr(session()->get('user_name'), 0, 2)) ?>
                </a>
            </div>
        </div>

        <!-- Stat Cards -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="stat">
                    <div class="stat-icon" style="background:#FAECE7">
                        <i class="bi bi-people" style="color:#D85A30"></i>
                    </div>
                    <div>
                        <div class="stat-num"><?= $total_users ?></div>
                        <div class="stat-label">Total User</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat">
                    <div class="stat-icon" style="background:#E1F5EE">
                        <i class="bi bi-person-badge" style="color:#0F6E56"></i>
                    </div>
                    <div>
                        <div class="stat-num"><?= $total_workers ?></div>
                        <div class="stat-label">Penyedia Jasa</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat">
                    <div class="stat-icon" style="background:#E6F1FB">
                        <i class="bi bi-grid" style="color:#185FA5"></i>
                    </div>
                    <div>
                        <div class="stat-num"><?= $total_categories ?></div>
                        <div class="stat-label">Kategori</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat">
                    <div class="stat-icon" style="background:#EEEDFE">
                        <i class="bi bi-receipt" style="color:#534AB7"></i>
                    </div>
                    <div>
                        <div class="stat-num"><?= $total_orders ?></div>
                        <div class="stat-label">Total Pesanan</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="mb-4">
            <div style="font-size:11px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">Akses Cepat</div>
            <div class="row g-3">
                <div class="col-md-3">
                    <a href="/admin/users/create" class="quick-btn">
                        <div class="quick-btn-icon" style="background:#FAECE7">
                            <i class="bi bi-person-plus" style="color:#D85A30"></i>
                        </div>
                        <div class="quick-btn-label">Tambah User</div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="/admin/categories/create" class="quick-btn">
                        <div class="quick-btn-icon" style="background:#E1F5EE">
                            <i class="bi bi-plus-circle" style="color:#0F6E56"></i>
                        </div>
                        <div class="quick-btn-label">Tambah Kategori</div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="/admin/workers" class="quick-btn">
                        <div class="quick-btn-icon" style="background:#E6F1FB">
                            <i class="bi bi-patch-check" style="color:#185FA5"></i>
                        </div>
                        <div class="quick-btn-label">Verifikasi Worker</div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="/admin/orders" class="quick-btn">
                        <div class="quick-btn-icon" style="background:#EEEDFE">
                            <i class="bi bi-eye" style="color:#534AB7"></i>
                        </div>
                        <div class="quick-btn-label">Lihat Pesanan</div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Tables -->
        <div class="row g-3">
            <div class="col-md-6">
                <div class="card-custom">
                    <div class="card-title-custom">
                        <i class="bi bi-people" style="color:#D85A30"></i>
                        User Terbaru
                    </div>
                    <?php foreach ($recent_users as $user): ?>
                    <div class="table-row">
                        <div class="mini-avatar" style="background:#FAECE7;color:#993C1D">
                            <?= strtoupper(substr($user['name'], 0, 2)) ?>
                        </div>
                        <div style="flex:1;font-size:13px;font-weight:500;color:#1a1a2e"><?= $user['name'] ?></div>
                        <span class="badge-<?= $user['role'] ?>"><?= $user['role'] ?></span>
                        <span style="font-size:11px;color:#aaa"><?= date('d/m/Y', strtotime($user['created_at'])) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card-custom">
                    <div class="card-title-custom">
                        <i class="bi bi-clipboard-list" style="color:#D85A30"></i>
                        Pesanan Terbaru
                    </div>
                    <?php if (!empty($recent_orders)): ?>
                        <?php foreach ($recent_orders as $order): ?>
                        <div class="table-row">
                            <div style="flex:1">
                                <div style="font-size:13px;font-weight:500;color:#1a1a2e"><?= $order['customer_name'] ?></div>
                                <div style="font-size:11px;color:#aaa"><?= $order['category_name'] ?></div>
                            </div>
                            <span class="badge-<?= $order['status'] ?>"><?= $order['status'] ?></span>
                        </div>
                        <?php endforeach; ?>
                        <div style="margin-top:14px;padding:12px;background:#f8f9fa;border-radius:10px">
                            <div class="d-flex justify-content-between mb-1">
                                <span style="font-size:12px;color:#888">Pesanan selesai</span>
                                <span style="font-size:12px;font-weight:600;color:#3B6D11">
                                    <?= count(array_filter($recent_orders, fn($o) => $o['status'] == 'done')) ?> pesanan
                                </span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span style="font-size:12px;color:#888">Menunggu konfirmasi</span>
                                <span style="font-size:12px;font-weight:600;color:#854F0B">
                                    <?= count(array_filter($recent_orders, fn($o) => $o['status'] == 'pending')) ?> pesanan
                                </span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-3" style="font-size:13px">Belum ada pesanan</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>