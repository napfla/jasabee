<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
        .cat-card { cursor: pointer; transition: 0.2s; text-decoration: none; color: inherit; }
        .cat-card:hover { border-color: #D85A30 !important; transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,0.1) !important; }
        .hero { background: linear-gradient(135deg, #D85A30, #e8824f); color: #fff; padding: 60px 0; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/customer/home">🐝 JasaBee</a>
        <div class="d-flex align-items-center gap-3">
            <a href="/customer/orders" class="text-white text-decoration-none">
                <i class="bi bi-clipboard-list me-1"></i>Pesanan Saya
            </a>
            <a href="/profile" class="text-white text-decoration-none">
                <i class="bi bi-person-circle me-1"></i>Profil
            </a>
            <span class="text-white">Hi, <?= session()->get('user_name') ?>!</span>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="hero">
    <div class="container text-center">
        <h1 class="fw-bold mb-3">Butuh bantuan? Kami siap!</h1>
        <p class="mb-0 opacity-75">Pilih kategori layanan yang kamu butuhkan</p>
    </div>
</div>

<div class="container py-5">
    <h5 class="fw-bold mb-4">Pilih Kategori Layanan</h5>
    <div class="row g-3">
        <?php if (!empty($categories)): ?>
            <?php foreach ($categories as $cat): ?>
            <div class="col-6 col-md-3">
                <a href="/customer/category/<?= $cat['id'] ?>" class="cat-card card border text-center p-4 h-100 d-block">
                    <div style="font-size:40px"><?= $cat['icon'] ?? '📦' ?></div>
                    <div class="fw-semibold mt-2"><?= $cat['name'] ?></div>
                    <div class="text-muted small mt-1"><?= $cat['description'] ?? '' ?></div>
                </a>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-muted py-5">
                <i class="bi bi-grid-x fs-1"></i>
                <p class="mt-2">Belum ada kategori tersedia</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Penyedia Jasa -->
    <h5 class="fw-bold mb-4 mt-5">Penyedia Jasa Tersedia</h5>
    <div class="row g-3">
        <?php if (!empty($workers)): ?>
            <?php foreach ($workers as $worker): ?>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div style="width:50px;height:50px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;font-weight:700;color:#D85A30;font-size:20px;flex-shrink:0">
                                <?= strtoupper(substr($worker['name'], 0, 1)) ?>
                            </div>
                            <div>
                                <div class="fw-semibold"><?= $worker['name'] ?></div>
                                <div class="text-muted small"><?= $worker['category_name'] ?></div>
                            </div>
                        </div>
                        <p class="text-muted small mb-3"><?= substr($worker['bio'] ?? 'Penyedia jasa profesional siap membantu.', 0, 100) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="fw-semibold" style="color:#D85A30"><?= $worker['price'] ?? '-' ?></span>
                            <span class="badge bg-success">Tersedia</span>
                        </div>
                        <a href="/customer/order/create/<?= $worker['id'] ?>" class="btn btn-orange btn-sm w-100">
                            <i class="bi bi-plus-circle me-1"></i>Pesan Sekarang
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-muted py-5">
                <i class="bi bi-person-x fs-1"></i>
                <p class="mt-2">Belum ada penyedia jasa tersedia</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>