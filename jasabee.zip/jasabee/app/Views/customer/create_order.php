<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Pesanan - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/customer/home">🐝 JasaBee</a>
        <div class="d-flex align-items-center gap-3">
            <a href="/customer/orders" class="text-white text-decoration-none">
                <i class="bi bi-clipboard-list me-1"></i>Pesanan Saya
            </a>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="d-flex align-items-center gap-2 mb-4">
        <a href="/customer/home" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left"></i>
        </a>
        <h4 class="mb-0">Buat Pesanan</h4>
    </div>

    <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Info Worker -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center p-4">
                    <div style="width:70px;height:70px;border-radius:50%;background:#FAECE7;display:flex;align-items:center;justify-content:center;font-weight:700;color:#D85A30;font-size:24px;margin:0 auto 12px">
                        <?= strtoupper(substr($worker['name'] ?? 'J', 0, 1)) ?>
                    </div>
                    <h5 class="fw-bold"><?= $worker['name'] ?? '-' ?></h5>
                    <p class="text-muted small mb-2"><?= $worker['bio'] ?? '-' ?></p>
                    <span class="badge bg-success">Tersedia</span>
                    <div class="mt-3 p-2 rounded" style="background:#FAECE7">
                        <div class="fw-semibold" style="color:#D85A30"><?= $worker['price'] ?? '-' ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Order -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <form action="/customer/order/store" method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden" name="worker_id" value="<?= $worker['id'] ?>">
                        <div class="mb-3">
                            <label class="form-label">Kategori Jasa</label>
                            <input type="hidden" name="category_id" value="<?= $worker['category_id'] ?>">
                            <input type="text" class="form-control" value="<?= $worker['category_name'] ?>" disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Deskripsi Masalah / Kebutuhan</label>
                            <textarea name="description" class="form-control" rows="4" placeholder="Ceritakan apa yang perlu dikerjakan..." required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat Lengkap</label>
                            <textarea name="address" class="form-control" rows="2" placeholder="Jl. ..." required></textarea>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Tanggal Pengerjaan</label>
                            <input type="date" name="date" class="form-control" required>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-orange">
                                <i class="bi bi-send me-1"></i>Kirim Pesanan
                            </button>
                            <a href="/customer/home" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>