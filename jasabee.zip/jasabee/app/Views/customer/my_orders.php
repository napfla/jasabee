<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Saya - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: #D85A30 !important; }
        .btn-orange { background: #D85A30; border-color: #D85A30; color: #fff; }
        .btn-orange:hover { background: #c04828; border-color: #c04828; color: #fff; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/customer/home">🐝 JasaBee</a>
        <div class="d-flex align-items-center gap-3">
            <a href="/customer/orders" class="text-white text-decoration-none fw-semibold">
                <i class="bi bi-clipboard-list me-1"></i>Pesanan Saya
            </a>
            <span class="text-white">Hi, <?= session()->get('user_name') ?>!</span>
            <a href="/logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <h4 class="fw-bold mb-4">Pesanan Saya</h4>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($orders)): ?>
        <?php foreach ($orders as $order): ?>
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <h6 class="fw-bold mb-1"><?= $order['category_name'] ?></h6>
                        <div class="text-muted small">
                            <i class="bi bi-person me-1"></i><?= $order['worker_name'] ?>
                        </div>
                    </div>
                    <span class="badge <?= 
                        $order['status'] == 'done' ? 'bg-success' : 
                        ($order['status'] == 'pending' ? 'bg-warning text-dark' : 
                        ($order['status'] == 'cancelled' ? 'bg-danger' : 'bg-info')) ?>">
                        <?= ucfirst($order['status']) ?>
                    </span>
                </div>
                <p class="text-muted small mb-2">
                    <i class="bi bi-card-text me-1"></i><?= $order['description'] ?>
                </p>
                <div class="d-flex gap-3 text-muted small">
                    <span><i class="bi bi-geo-alt me-1"></i><?= $order['address'] ?></span>
                    <span><i class="bi bi-calendar me-1"></i><?= $order['date'] ? date('d/m/Y', strtotime($order['date'])) : '-' ?></span>
                </div>

                <?php if ($order['status'] == 'done'): ?>
                <div class="mt-3 pt-3 border-top">
                    <form action="/customer/review/store" method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2">
                                <label class="form-label small">Rating</label>
                                <select name="rating" class="form-select form-select-sm">
                                    <option value="5">⭐⭐⭐⭐⭐</option>
                                    <option value="4">⭐⭐⭐⭐</option>
                                    <option value="3">⭐⭐⭐</option>
                                    <option value="2">⭐⭐</option>
                                    <option value="1">⭐</option>
                                </select>
                            </div>
                            <div class="col-md-7">
                                <label class="form-label small">Komentar</label>
                                <input type="text" name="comment" class="form-control form-control-sm" placeholder="Tulis ulasanmu...">
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-orange btn-sm w-100">
                                    <i class="bi bi-star me-1"></i>Beri Ulasan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="text-center text-muted py-5">
            <i class="bi bi-clipboard-x fs-1"></i>
            <p class="mt-2">Belum ada pesanan</p>
            <a href="/customer/home" class="btn btn-orange">Cari Penyedia Jasa</a>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>