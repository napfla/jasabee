<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .login-card { max-width: 420px; margin: 80px auto; }
        .btn-primary { background: #D85A30; border-color: #D85A30; }
        .btn-primary:hover { background: #c04828; border-color: #c04828; }
        .text-orange { color: #D85A30; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="card shadow-sm border-0 rounded-4 p-4">
            <div class="text-center mb-4">
                <h3 class="fw-bold text-orange">🐝 JasaBee</h3>
                <p class="text-muted">Masuk ke akunmu</p>
            </div>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>

            <form action="/login" method="POST">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Masuk</button>
            </form>

            <p class="text-center mt-3 mb-0">
                Belum punya akun? <a href="/register" class="text-orange">Daftar sekarang</a>
            </p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>