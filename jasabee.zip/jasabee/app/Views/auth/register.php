<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - JasaBee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .register-card { max-width: 480px; margin: 60px auto; }
        .btn-primary { background: #D85A30; border-color: #D85A30; }
        .btn-primary:hover { background: #c04828; border-color: #c04828; }
        .text-orange { color: #D85A30; }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="card shadow-sm border-0 rounded-4 p-4">
            <div class="text-center mb-4">
                <h3 class="fw-bold text-orange">🐝 JasaBee</h3>
                <p class="text-muted">Buat akun baru</p>
            </div>

            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach (session()->getFlashdata('errors') as $error): ?>
                            <li><?= $error ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="/register" method="POST">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="name" class="form-control" value="<?= old('name') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">No. HP</label>
                    <input type="text" name="phone" class="form-control" value="<?= old('phone') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="address" class="form-control" rows="2"><?= old('address') ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Daftar sebagai</label>
                    <select name="role" class="form-select" required>
                        <option value="">-- Pilih Role --</option>
                        <option value="customer" <?= old('role') == 'customer' ? 'selected' : '' ?>>Customer</option>
                        <option value="worker" <?= old('role') == 'worker' ? 'selected' : '' ?>>Penyedia Jasa</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Daftar Sekarang</button>
            </form>

            <p class="text-center mt-3 mb-0">
                Sudah punya akun? <a href="/login" class="text-orange">Masuk di sini</a>
            </p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>