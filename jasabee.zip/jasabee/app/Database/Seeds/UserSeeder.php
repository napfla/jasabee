<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            // Admin
            [
                'name'       => 'Admin JasaBee',
                'email'      => 'admin@jasabee.com',
                'password'   => password_hash('admin123', PASSWORD_DEFAULT),
                'phone'      => '081234567890',
                'address'    => 'Banjarmasin, Kalimantan Selatan',
                'role'       => 'admin',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            // Customer dummy
            [
                'name'       => 'Nafila',
                'email'      => 'nafila@gmail.com',
                'password'   => password_hash('nafila123', PASSWORD_DEFAULT),
                'phone'      => '085249063122',
                'address'    => 'Jl. Bahari, Martapura, Kalimantan Selatan',
                'role'       => 'customer',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            // Worker dummy
            [
                'name'       => 'Drake',
                'email'      => 'drake@gmail.com',
                'password'   => password_hash('drake123', PASSWORD_DEFAULT),
                'phone'      => '083456789012',
                'address'    => 'Jl. Gatot Subroto, Banjarmasin, Kalimantan Selatan',
                'role'       => 'worker',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
        ];

        $this->db->table('users')->insertBatch($data);
    }
}