<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddVerifiedToWorkersTable extends Migration
{
    public function up()
    {
        $this->forge->addColumn('workers', [
            'is_verified' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 0,
                'after'      => 'status',
            ],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('workers', 'is_verified');
    }
}