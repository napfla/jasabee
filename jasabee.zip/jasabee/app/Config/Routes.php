<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('/test', 'Test::index');

// Auth routes
$routes->get('/register', 'AuthController::register');
$routes->post('/register', 'AuthController::registerProcess');
$routes->get('/login', 'AuthController::login');
$routes->post('/login', 'AuthController::loginProcess');
$routes->get('/logout', 'AuthController::logout');


// Worker routes
$routes->get('/worker/dashboard', 'WorkerController::dashboard');
$routes->post('/worker/order/status/(:num)', 'WorkerController::updateStatus/$1');
$routes->get('/worker/profile/edit', 'WorkerController::editProfile');
$routes->post('/worker/profile/update', 'WorkerController::updateProfile');
$routes->get('/worker/complete-profile', 'WorkerController::completeProfile');
$routes->post('/worker/save-profile', 'WorkerController::saveProfile');

// Customer routes
$routes->get('/customer/home', 'CustomerController::home');
$routes->get('/customer/order/create/(:num)', 'CustomerController::createOrder/$1');
$routes->post('/customer/order/store', 'CustomerController::storeOrder');
$routes->get('/customer/orders', 'CustomerController::myOrders');
$routes->post('/customer/review/store', 'CustomerController::storeReview');

// Profile routes
$routes->get('/profile', 'ProfileController::index');
$routes->post('/profile/update', 'ProfileController::update');
$routes->post('/profile/password', 'ProfileController::updatePassword');

// Admin routes
$routes->group('admin', function($routes) {
    $routes->get('dashboard', 'Admin\AdminController::dashboard');

    // CRUD Users
    $routes->get('users', 'Admin\AdminController::users');
    $routes->get('users/create', 'Admin\AdminController::createUser');
    $routes->post('users/store', 'Admin\AdminController::storeUser');
    $routes->get('users/edit/(:num)', 'Admin\AdminController::editUser/$1');
    $routes->post('users/update/(:num)', 'Admin\AdminController::updateUser/$1');
    $routes->get('users/delete/(:num)', 'Admin\AdminController::deleteUser/$1');

    // CRUD Categories
    $routes->get('categories', 'Admin\AdminController::categories');
    $routes->get('categories/create', 'Admin\AdminController::createCategory');
    $routes->post('categories/store', 'Admin\AdminController::storeCategory');
    $routes->get('categories/edit/(:num)', 'Admin\AdminController::editCategory/$1');
    $routes->post('categories/update/(:num)', 'Admin\AdminController::updateCategory/$1');
    $routes->get('categories/delete/(:num)', 'Admin\AdminController::deleteCategory/$1');

    // CRUD Workers
    $routes->get('workers', 'Admin\AdminController::workers');
    $routes->get('workers/create', 'Admin\AdminController::createWorker');
    $routes->post('workers/store', 'Admin\AdminController::storeWorker');
    $routes->get('workers/edit/(:num)', 'Admin\AdminController::editWorker/$1');
    $routes->post('workers/update/(:num)', 'Admin\AdminController::updateWorker/$1');
    $routes->get('workers/delete/(:num)', 'Admin\AdminController::deleteWorker/$1');
    $routes->get('workers/verify/(:num)', 'Admin\AdminController::verifyWorker/$1');
    $routes->get('workers/unverify/(:num)', 'Admin\AdminController::unverifyWorker/$1');

    // CRUD Orders
    $routes->get('orders', 'Admin\AdminController::orders');
    $routes->get('orders/(:num)', 'Admin\AdminController::orderDetail/$1');
    $routes->post('orders/status/(:num)', 'Admin\AdminController::updateOrderStatus/$1');
    $routes->get('orders/delete/(:num)', 'Admin\AdminController::deleteOrder/$1');

    // Reviews
    $routes->get('reviews', 'Admin\AdminController::reviews');
});